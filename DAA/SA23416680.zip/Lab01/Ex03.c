#include <stdio.h>

int main() {
    printf("My Name is Lasindu Anjana\n");
    printf("My Registration Number is SA23416680\n");
    return 0;