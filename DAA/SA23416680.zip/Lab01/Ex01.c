#include <stdio.h>
int main()
{
    printf("Welcome to C Lanuange Wold");
    return 0;
}